import { createStore } from 'vuex'

// Create a new store instance.
const store = createStore({
  state () {
    return {
      times:[]
    }
  },
  mutations: {
   times_carregar(state, times){
     state.times = times
   }
  },
  actions:{
    async carregar({commit}){
      let times = [
        {timeId: '1', nome: 'Vasco', golsMarcados: '10'},
        {timeId: '2', nome: 'Botafogo', golsMarcados: '20'},
        {timeId: '3', nome: 'Flamengo', golsMarcados: '30'},
        {timeId: '4', nome: 'Madureira', golsMarcados: '40'},
        {timeId: '5', nome: 'Fluminense', golsMarcados: '50'},
        {timeId: '6', nome: 'Bangu', golsMarcados: '60'},
        {timeId: '7', nome: 'NovaIguacu', golsMarcados: '70'},
      ]
      commit("carregar", times)
    }
  }
})


export default store
