<template>
  <h1>HISTÓRICO DE PARTIDAS</h1>
  <h2>PAINEL DA PARTIDA</h2>
</template>

<script>
export default {
  name: "Partidas"
}
</script>

<style scoped>
</style>
